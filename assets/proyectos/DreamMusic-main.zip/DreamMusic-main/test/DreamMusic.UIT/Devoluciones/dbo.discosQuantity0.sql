SET IDENTITY_INSERT [dbo].[Discos] ON
UPDATE [dbo].[Discos] SET CantidadDevolucion=0 FROM [dbo].[Discos]
SET IDENTITY_INSERT [dbo].[Discos] OFF